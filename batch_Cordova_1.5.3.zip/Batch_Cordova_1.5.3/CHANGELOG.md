Batch Cordova Plugin

1.5.3
----
Update native SDKs to 1.5.3

1.5
----
Update native SDKs to 1.5
Custom user data (attributes, tags and events)
Added an API to retrieve Batch's unique installation identifier
Deprecated BatchUserProfile
Added ability to start Batch in a service

1.4
----
Update native SDKs to 1.4
iOS 9 and bitcode support

1.3.3 Beta 3
------------
Batch Push has a new method to allow you to get the last known push token

1.3.3 Beta 2
------------
Updated native sdks to 1.3.3 (prerelease)  

Batch Push is now fully available: 
 - It is now possible to read the notification payload in your JS code
 - Setting the wanted notification types is supported

Added Batch Unlock

1.3.2 Beta 1
------------

Initial release
